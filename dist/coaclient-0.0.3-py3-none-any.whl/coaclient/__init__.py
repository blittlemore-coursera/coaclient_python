"""Coaclient module"""
from .version import __version__
